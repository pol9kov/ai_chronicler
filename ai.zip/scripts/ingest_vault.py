def load_config():
    from pathlib import Path
    return Path.cwd()

def ingest():
    print("Ingested 0 tagged notes.")

# makes 'scripts' a Python package
